package com.princessCruise.web.automation.logs;

public enum CustomLogName {
	CurrentTestClassLog,CurrentGlobalLog,CurrentTestCaseLog,CurrentSiteCoreLog
}
