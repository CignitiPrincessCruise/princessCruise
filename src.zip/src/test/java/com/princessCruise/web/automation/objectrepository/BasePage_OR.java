package com.princessCruise.web.automation.objectrepository;

public class BasePage_OR {
	

}
