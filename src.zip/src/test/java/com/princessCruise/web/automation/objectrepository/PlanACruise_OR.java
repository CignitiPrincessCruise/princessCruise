package com.princessCruise.web.automation.objectrepository;

import org.openqa.selenium.By;

public class PlanACruise_OR {
	public static By PlanACruise = By.xpath(".//*[@data-us-text='Plan a Cruise']");

}
