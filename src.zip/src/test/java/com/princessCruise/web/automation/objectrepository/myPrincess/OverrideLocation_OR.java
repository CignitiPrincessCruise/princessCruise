package com.princessCruise.web.automation.objectrepository.myPrincess;

import org.openqa.selenium.By;

public class OverrideLocation_OR {
	public static By btnSubmit = By.id("submit");

}
