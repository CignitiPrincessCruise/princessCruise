package com.princessCruise.web.automation.pages.ezAir;
import java.util.List;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.google.common.base.Optional;
import com.princessCruise.web.automation.accelerators.ActionsLibrary;
import com.princessCruise.web.automation.logs.ExtentLogs;
import com.princessCruise.web.automation.utilities.CommonVariables;
import com.princessCruise.web.automation.utilities.ConfigManager;

public class LandingEZ {
	public WebDriver driver;
	public ActionsLibrary actionLib;
	public ExtentLogs extentLogs=new ExtentLogs();
	Optional<Long> timeoutInSecond = Optional.of(Long.parseLong("5"));
	public LandingEZ(WebDriver driver)
	{
		if(CommonVariables.getDriver()==null){
			CommonVariables.setDriver(driver);
		}
		actionLib = CommonVariables.getActionLib();
		try {
			if(!ConfigManager.ArePropertiesSet.get()){
				ConfigManager.setProperties();
				ConfigManager.UpdateProperties();
			}
		} 
		catch (Exception e) {
			System.out.println("Failed to load Properties file");
		}
	}
	public String fromCityvalue;
	public String toCityValue;
	public static By chkGuest1 = By.xpath("//div[@id='ez-search-unbooked']//input[@id='ez-guest-id-01']");
	public static By chkGuest2 = By.xpath("//div[@id='ez-search-unbooked']//input[@id='ez-guest-id-02']");
	public static By ddnDirection = By.xpath("//select[@id='ez-search-direction']/option[@selected='selected']");
	public static By ddnClass = By.xpath("//select[@id='ez-search-class']/option[@selected='selected']");
	public static By ddnMaxStops = By.xpath("//select[@id='ez-search-nonstop']");
	public static By ddnAirline = By.xpath("//select[@id='ez-search-airline']/option[@selected='selected']");
	public static By lblDepToCity = By.xpath("//span[@id='ez-search-dpt-city-title']");
	public static By ddnDepTo = By.xpath("//select[@id='ez-search-dpt-to-singlecity']//option[@selected='selected']");
	public static By ddnDepFrom = By.xpath("//input[@id='ez-search-dpt-from-singlecity-extended']");
	public static By txtBoxReturnTo = By.cssSelector("#ez-search-rtn-to-singlecity-extended");
	public static By ddnReturnFrom = By.xpath("//select[@id='ez-search-rtn-from-singlecity']//option[@selected='selected']");
	public static By btnSearch = By.xpath("//button[@id='search-submit-btn']");
	public static By departureFormFields = By.cssSelector("#ez-search-dpt-body #ez-search-dpt-fields div[class^='ez-search'] .row>span");
	public static By returnFormFields = By.cssSelector("#ez-search-rtn-body #ez-search-rtn-fields div[class^='ez-search'] .row>span");
	public static By btnDepAddFlight = By.xpath("//button[@id='ez-search-dpt-add']");
	public static By btnRetAddFlight = By.xpath("//button[@id='ez-search-rtn-add']");
	public static By txtBoxArriveOn = By.xpath("//input[@id='ez-search-dpt-arrival-date-singlecity']");
	public static By lblFromAndToCity = By.xpath("//h1[text()='Select Your Departure Flight']/following-sibling::h2/span");
	public static By lblRetFromAndToCity = By.xpath("//h1[text()='Select Your Return Flight']/following-sibling::h2/span");
	public static By currencyFares = By.cssSelector("#ez-rslt-main-container form[id='ez-rslt-main']>div:nth-child(2)>div:nth-child(2) [class^='ez-fare-total']");
	public static By listOfFlights = By.xpath("//div[contains(text(),'Total Duration')]");
	public static By lblFlightsFound = By.xpath("//span[@id='ez-rslt-found-count']");
	public static By ddnSortBy = By.xpath("//select[@id='ez-rslt-sort']");
	public static By lnkFlexibleAndRestrictedFares = By.xpath("//a[@title='Fare Type Comparison Chart']");
	public static By btnPopUpClose = By.xpath("//button[@title='Close (Esc)']");
	public static By lnkShowDetails = By.xpath("//a[text()='Show details']");
	public static By lnkFareRestrictions = By.xpath("//a[text()='Fare Restrictions']");
	public static By lblFlexibleDescription = By.xpath("//div[@id='ez-flexible-disclaimer-tab']/ul/li");
	public static By btnRestricted = By.xpath("//a[@title='Restricted']");
	public static By lblRestrictedDescription = By.xpath("//div[@id='ez-restricted-disclaimer-tab']/ul/li");
	public static By lblFilters = By.xpath("//div[@id='ez-rslt-filters']//fieldset[@class='no-spacing']/legend");
	public static By btnDepFlexibleSelect = By.cssSelector("#ez-rslt-main-container form[id='ez-rslt-main'] div[data-faretype='flexible'] button");
	public static By btnDepRestrictedSelect = By.cssSelector("#ez-rslt-main-container form[id='ez-rslt-main'] div[data-faretype='restricted'] button");
	public static By lblReturn = By.xpath("//div[@id='ez-rslt-header-return']//h1[@class='sm-inline-block no-caps']");
	public static By lblAirlineName = By.cssSelector("#ez-rslt-main-container form[id='ez-rslt-main']>div>div h3");
	public static By flightSchedule = By.cssSelector("#ez-rslt-main-container form[id='ez-rslt-main']>div div [class^='itn-origin'] time");
	public static By lblFlightDuration = By.cssSelector("#ez-rslt-main-container form[id='ez-rslt-main']>div div [class^='itn-total-duration']");
	public static By lblSummary = By.xpath("//li[@id='ez-step-summary']");
	public static By lblSummaryHeader =By.xpath("//div[@id='ez-rslt-header-summary']/h1");
	public static By btnRetFlexibleSelect = By.cssSelector("#ez-rslt-return-container form[id='ez-rslt-return'] div[data-faretype='flexible'] button");
	public static By btnRetRestrictedSelect = By.cssSelector("#ez-rslt-return-container form[id='ez-rslt-return'] div[data-faretype='restricted'] button");
	public static By btnPopUpContinue = By.xpath("//div[@id='popupContent']//button[text()='Continue']");
	public static By lblFlexibleFareCard = By.cssSelector("form[id='ez-rslt-main'] div[data-faretype='flexible'] [class^='ez-fare-info gotham']");
	public static By lblRestrictedFareCard = By.cssSelector("form[id='ez-rslt-main'] div[data-faretype='restricted'] [class^='ez-fare-info gotham']");
	public static By logoEZAir = By.xpath("//div[@class='ez-waiting-logo']");
	public static By lblCruiseDeparture = By.xpath("//span[text()='Cruise Departure:']/following-sibling::span");
	public static By lblCruiseReturn = By.xpath("//span[text()='Cruise Return:']/following-sibling::span");
	public static By ddnArriveBy = By.cssSelector("#ez-search-dpt-arrival-time-singlecity");
	public static By txtBoxLeaveOn = By.cssSelector("#ez-search-rtn-depart-date-singlecity");
	public static By ddnLeaveAt = By.cssSelector("#ez-search-rtn-depart-date-singlecity");
	public static By lblLandingPageHeader = By.cssSelector("#ez-search-header>h1");
	public static By lblStepBar = By.cssSelector("#steps-bar>ol>li div:nth-child(1)");

	public void verifyLandingPageIsDisplayed(String landingPageHeader){
		try {
			String headerText = actionLib.getElementText(lblLandingPageHeader, "Found Text Value");
			actionLib.compareValues(landingPageHeader, headerText, "Actual and Expected values are not same");
			extentLogs.pass("Landing Page", "Successfully Verified Landing Page Is Displayed");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Landing Page","Unable to Verify Landing Page");
		}
	}
	public void verifyStepBar(){
		try {
			verifyDataIsDisplayed(lblStepBar);
			extentLogs.pass("Steps Bar", "Successfully Verified Steps Bar Is Displayed");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Steps Bar","Unable to Verify Steps Bar");
		}
	}
	public void verifyAllGuests(By element){
		try {
			boolean  value = CommonVariables.CommonDriver.get().findElement(element).isSelected();
			if(value == true){
				extentLogs.pass("Guests Check Box", "Successfully Verifieed Guests check Box");
			}
		} catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Guests Check Box","Unable to Verify Guests Check Box");
		}
	}

	public void verifyArriveAndLeaveOnFields(By field , By label){
		try {
			String actual = actionLib.getElementAttribute(field,"value","Found Value");
			String expected = actionLib.getElementText(label,"Found Label Value");
			Assert.assertNotNull("Is Not Null Verified", field);
			actionLib.checkStringContains(expected,actual, "Successfully Verified Arrive and Leave On Field is not null");
			extentLogs.pass("Arrive and Leave On Field", "Successfully Verified Arrive and Leave On Field is not null");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Arrive and Leave On Field","Unable to Verify  Arrive and Leave On Field is not null");
		}
	}
	public void verifyFieldValue(By element){
		try {
			Assert.assertNotNull("Is Not Null Verified", element);
			extentLogs.pass("Field", "Successfully Verified Field is not null");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Field","Unable to Verify Field is not null");
		}
	}
	public void verifyFlightOptionDropDowns(By element , String defalutValue){
		try {
			String defaultValueText = actionLib.getElementText(element, "Found Text Value");
			actionLib.compareValues(defalutValue, defaultValueText, "Actual and Expected values are not same");
			extentLogs.pass("Choose Flight Options", "Successfully Verified Flight Options");
		} catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Choose Flight Options", "Unable to Verify Flight Options");
		}
	}
	public void verifyDropDownDefaultValue(String defalutValue,By element){
		try {
			WebElement option = CommonVariables.CommonDriver.get().findElement(element);
			Select defaultValue = new Select(option);
			String value = defaultValue.getFirstSelectedOption().getText();
			actionLib.compareValues(value, defalutValue, "Actual and Expected value are not same");
			extentLogs.pass("Verify Drop Down Default VAlue", "Successfully Verified Drop Down Default Value");
		} catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Verify Drop Down Default VAlue", "Unable to Verify Drop Down Default Value");
		}
	}
	public void verifyDepartureToAndReturnFromDropDown(){
		try {
			String lblDepText = actionLib.getElementText(lblDepToCity, "Found Label Departure Text");
			String ddnDepToValue = actionLib.getElementText(ddnDepTo, "Found Departure To DropDown");
			String ddnReturnFromValue = actionLib.getElementText(ddnReturnFrom, "Found Return From DropDown");
			actionLib.compareValues(ddnDepToValue, ddnReturnFromValue, "Actual and Expected value are not same");
			actionLib.checkStringContains(ddnDepToValue.toUpperCase(),lblDepText.toUpperCase(), "Actual and Expected value are not same");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Choose Flight Options", "Unable to Verify Flight Options");
		}		
	}
	public void popUpClose(){
		try {
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnPopUpClose), "Pop - Up Close Button");
			extentLogs.pass("Pop - Up Close Button", "Successfully Clicked On Pop - Up Close Button");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Pop - Up Close Button", "Unable to Perform Click Operation on Pop - Up Close Button");
		}
	}
	public void clickOnSearchButton(){
		try {
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnSearch), "Search Button");
			actionLib.waitForVisibilityOfElement(logoEZAir, "Waiting Page After Cliking on Search Button", 300000);
			extentLogs.pass("Search Button", "Successfully Clicked On Search Button");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Search Button", "Unable to Perform Click Operation on Search Button");
		}
	}
	public void verifyRetAndDepAddFlight(By element ,By button){
		try {
			int ddnList = actionLib.CountElement(element, timeoutInSecond, "List of Drop Down Before Stoppers");
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(button), button+" Button");
			int ddnList2 = actionLib.CountElement(element, timeoutInSecond, "List of Drop Down After Stoppers");
			Assert.assertFalse(ddnList!=ddnList2);
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(button), button+" Button");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Search Button", "Unable to Perform Click Operation on Search Button");
		}
	}

	public String getFromCity(By element){
		try {
			fromCityvalue = actionLib.getElementText(element, "Found Value");
		}
		catch(Throwable e){
			e.printStackTrace();	
		}
		return fromCityvalue;
	}
	public String getToCity(By element){
		try {
			toCityValue = actionLib.getElementAttribute(element,"value","Found Value");
			Thread.sleep(10000);
		}
		catch(Throwable e){
			e.printStackTrace();

		}
		return toCityValue;
	}

	public void verifyFromPortAndToPortAndDate(String journey ,By element){
		try {
			String expectedValue;
			if(journey == "Return"){
				expectedValue = fromCityvalue + " To " + toCityValue  + " on ";
			}
			else{
				expectedValue = toCityValue  + " To " + fromCityvalue  + " on ";
			}
			String actualValue = actionLib.getElementText(element, "Found home airport to port city and date");
			Assert.assertTrue(actualValue.contains(expectedValue));
			extentLogs.pass("From and To Port City And Date", "Successfully Verify From and To Port City And Date");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("From and To Port City And Date", "Unable to Verify From and To Port City And Date");
		}
	}
	public void verifyEZAirLogo(){
		try {
			if(actionLib.IsElementVisible(logoEZAir)){
				actionLib.waitForVisibilityOfElement(lblFromAndToCity, "Departure Header Label", 40000);
				System.out.println("Wait for the page to the load");
			}
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Currency Fares", "Unable to Verify Currency Fares");
		}
	}
	public void verifyCurrencyFares(){
		try {
			if(actionLib.IsElementVisible(currencyFares)){
				List<WebElement> fares = actionLib.FindElements(currencyFares, timeoutInSecond);
				for(WebElement price :fares){
					String priceValue = price.getText().toString();
					Assert.assertTrue(priceValue.contains("$"));
					extentLogs.pass("Currency Fares", "Successfully Verified Currency Fares");
				}
			}
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Currency Fares", "Unable to Verify Currency Fares");
		}
	}

	public void verifyNoOfFlightsFound(){
		try {
			int noOfFlights  = actionLib.CountElement(lblFlightDuration, timeoutInSecond, "No Of Flights Found");
			String lblFlightsFoundText = actionLib.getElementText(lblFlightsFound, "No Of Flights");	
			int flightCount = Integer.parseInt(lblFlightsFoundText.substring(0,2));
			Assert.assertTrue(noOfFlights==flightCount);
			extentLogs.pass("Number Of Flights Found", "Unable to Verify Number of Flights Found");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Number Of Flights Found", "Successfully Verified Number of Flights Found");
		}
	}
	public void clickOnWhatAreFlexAndRestFares(){
		try {
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(lnkFlexibleAndRestrictedFares), "Flexible And Restricted Fares");
			popUpClose();
			extentLogs.pass("Flexible And Restricted Fares", "Successfully Clicked On Flexible And Restricted Fares");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Flexible And Restricted Fares", "Unable to Perform Click Operation On Flexible And Restricted Fares");
		}
	}

	public void clickOnShowDetails(){
		try {
			List<WebElement> showDetails = actionLib.FindElements(lnkShowDetails, timeoutInSecond);
			for(WebElement flightDetails :showDetails){
				flightDetails.click();
				popUpClose();
				break;
			}
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Link Show Details", "Unable to Perform Click Operation On Show Details");
		}
	}
	public void verifyDataIsDisplayed(By element){
		try {
			List<WebElement> fareDescription = actionLib.FindElements(element,timeoutInSecond);
			for(WebElement description :fareDescription){
				Assert.assertTrue(description.isDisplayed());
			}
			extentLogs.pass("Description Of Flexible and Restricted Types", "Verified Description Of Flexible and Restricted Types");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Description Of Flexible and Restricted Types", "Unable to Verify Description Of Flexible and Restricted Types");
		}
	}

	public void clickOnFareRestrictions(){
		try {
			List<WebElement> fareRestrictions = actionLib.FindElements(lnkFareRestrictions, timeoutInSecond);
			for(WebElement fareResriction :fareRestrictions){
				fareResriction.click();
				actionLib.waitForVisibilityOfElement(lblFlexibleDescription, "Flexible", 5000);
				verifyDataIsDisplayed(lblFlexibleDescription);
				actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnRestricted), "Restricted Fares");
				actionLib.waitForVisibilityOfElement(lblRestrictedDescription, "Restricted", 5000);
				verifyDataIsDisplayed(lblRestrictedDescription);
				popUpClose();
				break;
			}
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Link Fare Restrictions", "Unable to Perform Click Operation On Link Fare Restrictions");
		}
	}
	public void verifyFilters(){
		try {
			verifyDataIsDisplayed(lblFilters);
			extentLogs.pass("List of Filters", "Verified List of Filters");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("List of Filters", "Unable to Verify List of Filters");
		}
	}
	public void clickOnSelectButton(By element){
		try {
			List<WebElement> fareTypeList= actionLib.FindElements(element, timeoutInSecond);
			for(WebElement type :fareTypeList){
				type.click();
				Thread.sleep(10000);
				break;
			}
			extentLogs.pass("Select Button", "Successfully Clicked On Select Button");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Select Button", "Unable to Perform Click Operation on Select Button");
		}
	}
	public void vereifyReturnFlightPage(By fareType) throws InterruptedException{
		try {
			clickOnSelectButton(fareType);
			Thread.sleep(10000);
			try{
				int value = CommonVariables.CommonDriver.get().findElements(By.xpath("//div[@id='popupContent']//button[text()='Continue']")).size();
				if(value>0){
					actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnPopUpContinue), "Pop-Up Close button");
					Thread.sleep(10000);
				}
			}
			catch(Exception e2){
				System.out.println("No Pop-Up is Displayed.....");
			}
			Thread.sleep(10000);
			Assert.assertTrue(CommonVariables.CommonDriver.get().findElement(lblReturn).isDisplayed());
			extentLogs.pass("Select Button", "Successfully Clicked On Select Button");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Select Button", "Unable to Perform Click Operation on Select Button");
		}
	}
	public void verifySummaryPage(By element){
		try {
			clickOnSelectButton(element);
			Thread.sleep(10000);
			try{
				int value = CommonVariables.CommonDriver.get().findElements(By.xpath("//div[@id='popupContent']//button[text()='Continue']")).size();
				if(value<0){
					actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnPopUpContinue), "Pop-Up Close button");
					Thread.sleep(10000);
				}
			}
			catch(Exception e2){
				System.out.println("No Pop-Up is Displayed....");
			}
			Thread.sleep(10000);
			String summaryLabel = actionLib.getElementAttribute(lblSummary, "class", "Found Class Attribute");
			Assert.assertTrue(summaryLabel.contains("active"));
			Assert.assertTrue(CommonVariables.CommonDriver.get().findElement(lblSummaryHeader).isDisplayed());
			extentLogs.pass("Select Button", "Successfully Clicked On Select Button");

		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Select Button", "Unable to Perform Click Operation on Select Button");
		}
	}

	public void verifyFlightOptions(){
		try {
			verifyDataIsDisplayed(lblAirlineName);
			verifyDataIsDisplayed(flightSchedule);
			verifyDataIsDisplayed(lblFlightDuration);
			extentLogs.pass("Flight Options", "Verified Flight Options");
		}
		catch(Throwable e){
			e.printStackTrace();
			extentLogs.fail("Flight Options", "Unable to Verify Flight Options");
		}
	}
}
