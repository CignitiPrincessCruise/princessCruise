package com.princessCruise.web.automation.pages.polarBear;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.google.common.base.Optional;
import com.princessCruise.web.automation.accelerators.ActionsLibrary;
import com.princessCruise.web.automation.logs.ExtentLogs;
import com.princessCruise.web.automation.utilities.CommonVariables;
import com.princessCruise.web.automation.utilities.ConfigManager;

public class DetailsPage {


	public static By btnCruiseDetail = By.xpath("//button[text()='Cruise Details']");
	public static By btnSelectARoom = By.xpath("//button/span[@class='xs-hidden sm-hidden']");
	public static By btnSelectStateroomType = By.id("roomTypes");
	public static By btnselectroom = By.xpath("//div[@id='container']//div[@id='suite']//button[@class='button green-btn select-stateroom-btn font-size-btn']");
	public static By btnchangedate  = By.xpath("//div[@id='container']//select[@id='meta-departure-date-select']");
	public static By btnCruiseDetails = By.xpath("//div[@class='result-box']//button[@id='select-cruise-details-H780']");	
	public static By txtstatromm = By.xpath("//div[@id='content']//header/div[3]/div/h1");
 
	public WebDriver driver;
	public ActionsLibrary actionLib;
	public ExtentLogs extentLogs=new ExtentLogs();
	Optional<Long> timeoutInSecond = Optional.of(Long.parseLong("100000"));
	public DetailsPage(WebDriver driver)
	{
		if(CommonVariables.getDriver()==null){
			CommonVariables.setDriver(driver);
		}
		actionLib = CommonVariables.getActionLib();
		try {
			if(!ConfigManager.ArePropertiesSet.get()){
				ConfigManager.setProperties();
				ConfigManager.UpdateProperties();
			}
		} 
		catch (Exception e) {
			System.out.println("Failed to load Properties file");
		}
	}
	
	
	public void clickOnCruiseDetail() throws Throwable{
		try
		{
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnCruiseDetail));
			extentLogs.pass("click Cruise Details button", "Clicked on Cruise Details Button successfully.");
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("click Cruise Details button", "Clicking on Cruise Details Button is Unsuccessful.");
		}
	}
	
	
	public void clickOnSelectARoom() throws Throwable{
		try
		{
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnSelectARoom));
			extentLogs.pass("click Select A Room button", "Clicked on Select A Room Button successfully.");
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("click Select A Room button", "Clicking on Select A Room Button is Unsuccessful.");
		}
	}
	
	public void clickOnSelectStateroomType() throws Throwable{
		try
		{
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnSelectStateroomType));
			extentLogs.pass("click on Stateroom Tab", "Clicked on Stateroom tab is successful.");
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("click on Stateroom Tab", "Clicking on Stateroom tab is Unsuccessful.");
		}
	}
	
	public void clickOnSelectStateroom() throws Throwable{
		
		try
		{
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnselectroom));
			extentLogs.pass("click on Stateroom", "Clicked on Stateroom is successful.");
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("click on Stateroom", "Clicking on Stateroom is Unsuccessful.");
		}
		
	}
	
	
	public void clickOnChangeDateDropdown() throws Throwable{
		
		try
		{
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnchangedate));
			extentLogs.pass("click on Select a Date Dropdown", "Click on Select a Date Dropdown is successful.");
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("Click on Select a Date Dropdown", "Clicking on Select a Date Dropdown Unsuccessful.");
		}
		
	}
	
	public void clickOnCruiseDetailsButon() {
		if(actionLib.IsElementVisible(btnCruiseDetails)) {
			try {
				actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnCruiseDetails));
				extentLogs.pass("Click on Cruise Details button", "Clicked on Cruise Details successfully.");
				
			} catch(Throwable e) {
				extentLogs.fail("Click on Cruise Details button", "Clicked on Cruise Details successfully.");
				e.printStackTrace();
			}
		}
	}
	
	public void selectNewDate(String value) throws Throwable{
		try
		{
			actionLib.selectBySendkeys(btnchangedate, value, "Select a Date");
			extentLogs.pass("Select a Date", "Selected new date successfully.");
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("Select a Date", "Selecting new date is Unsuccessful.");
		}
		
	}
	

}
