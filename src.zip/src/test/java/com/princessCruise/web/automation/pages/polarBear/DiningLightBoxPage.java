package com.princessCruise.web.automation.pages.polarBear;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.google.common.base.Optional;
import com.princessCruise.web.automation.accelerators.ActionsLibrary;
import com.princessCruise.web.automation.logs.ExtentLogs;
import com.princessCruise.web.automation.utilities.CommonVariables;
import com.princessCruise.web.automation.utilities.ConfigManager;

public class DiningLightBoxPage {
	
	public static By ddnDiningOptionAnytimeDin = By.id("type-anytime");
	public static By ddnDiningOptionTradDin = By.id("type-traditional");
	public static By ddnDiningTime = By.id("dining-time");
	public static By ddnTableSize = By.id("table-size");
	public static By chooseaDffroombtn = By.xpath("//[@id='select-stateroom']/div/button[2]");
	public static By btnDeckOption_Club = By.cssSelector("#deck-9-A-M #deck-9-A-M-wrapper #group-C746>a");

	public WebDriver driver;
	public ActionsLibrary actionLib;
	public ExtentLogs extentLogs=new ExtentLogs();
	Optional<Long> timeoutInSecond = Optional.of(Long.parseLong("100000"));
	public DiningLightBoxPage(WebDriver driver)
	{
		if(CommonVariables.getDriver()==null){
			CommonVariables.setDriver(driver);
		}
		actionLib = CommonVariables.getActionLib();
		try {
			if(!ConfigManager.ArePropertiesSet.get()){
				ConfigManager.setProperties();
				ConfigManager.UpdateProperties();
			}
		} 
		catch (Exception e) {
			System.out.println("Failed to load Properties file");
		}
	}
	
	public void selectDiningOption(By element) throws Throwable{
		try
		{			
			actionLib.FindElement(element, timeoutInSecond).click();
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
		extentLogs.pass("Dining Option", "'Dining Option DropDown' Dining Option Value Found.");
	}
	
	public void selectDiningTime(String diningTime) throws Throwable{
		try
		{
		actionLib.FindElement(ddnDiningTime, timeoutInSecond).click();
		actionLib.selectBySendkeys(ddnDiningTime, diningTime,"Dining Time");
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
		extentLogs.pass("Dining Time", "'Dining Time DropDown' Dining Time Value Found.");
	}
	
	public void selectDiningTableSize(String diningTableSize) throws Throwable{
		try
		{
		actionLib.selectByVisibleText(ddnTableSize, diningTableSize, "Dining Table Size");	
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
		extentLogs.pass("Dining Table Size", "'Dining Table Size DropDown' Dining Table Size Value Found.");
	}
	
	public void selectDifferentStateroom(By element) throws Throwable{
		
		try
		{
			if(actionLib.IsElementVisible(chooseaDffroombtn)) {
				actionLib.FindElement(chooseaDffroombtn, timeoutInSecond).click();
				actionLib.FindElement(StateroomPage.btnDeckOption, timeoutInSecond).click();
				selectDiningOption(element);
			}
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
				
	}
	
	public void Close_the_Dinning_and_stateroom_page() throws Throwable{
		try
		{
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(SearchLandingPage.btnpopUpClose));
			extentLogs.pass("Closed the Dining and Stateroom Page", "Closed the Dining and Stateroom Page is successful");
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("Closed the Dining and Stateroom Page", "Closed the Dining and Stateroom Page is Unsuccessful");
		}
	}
	
	public void Select_other_Stateroom(){
		
		try
		{
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(btnDeckOption_Club));
			extentLogs.pass("Select stateroom ", "Selecting the stateroom is successful.");
		}	
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("click stateroom", "Selecting the stateroom is Unsuccessful.");
		}
	}	
	
		
}
