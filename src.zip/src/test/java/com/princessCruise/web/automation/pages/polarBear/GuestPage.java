package com.princessCruise.web.automation.pages.polarBear;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.google.common.base.Optional;
import com.princessCruise.web.automation.accelerators.ActionsLibrary;
import com.princessCruise.web.automation.logs.ExtentLogs;
import com.princessCruise.web.automation.utilities.CommonVariables;
import com.princessCruise.web.automation.utilities.ConfigManager;

public class GuestPage {
	
	public static By btncontinue = By.xpath("//button[text()='Continue']");
	public static By lnkSignin = By.xpath("//div[@id='main-content']//div[1]/button/div/span[2]");
	public static By txtEmailId = By.xpath("//form[@id='log-in']//input[@type='email']");
	public static By txtpasswd = By.xpath("//form[@id='log-in']//input[@type='password']");
	public static By btnsignin = By.xpath("//form[@id='log-in']//button[@id='signIn']");
	public static By btntitleG1 = By.xpath("//div[@id='paxDetail1_Form']//select[@id='pax1_title']");
	public static By txtfirstnameG1 = By.xpath("//div[@id='paxDetail1_Form']//input[@id='pax1_firstName']");
	public static By txtmiddlenameG1 = By.xpath("//div[@id='paxDetail1_Form']//input[@id='pax1_middleName']");
	public static By txtlastnameG1 = By.xpath("//div[@id='paxDetail1_Form']//input[@id='pax1_lastName']");
	public static By txtmonthG1 = By.xpath("//div[@id='paxDetail1_Form']//input[@id='pax1_birthMonth']");
	public static By txtdateG1 = By.xpath("//div[@id='paxDetail1_Form']//input[@id='pax1_birthDate']");
	public static By txtyearG1 = By.xpath("//div[@id='paxDetail1_Form']//input[@id='pax1_birthYear']");
	public static By txtPrimaryphnoG1 = By.xpath("//div[@id='paxDetail1_Form']//input[@id='pax1_phone']");
	public static By btnselecttypeG1 = By.xpath("//div[@id='paxDetail1_Form']//select[@id='pax1_phoneType']");
	public static By txtmailG1 = By.xpath("//div[@id='paxDetail1_Form']//input[@id='pax1_email']");
	public static By txtconfrmmailG1 = By.xpath("//div[@id='paxDetail1_Form']//input[@id='pax1_confirmEmail']");	
	public static By txtaddressG1 = By.xpath("//div[@id='paxDetail1_Form']//input[@id='pax1_address1']");	
	public static By btnCityG1 = By.xpath("//div[@id='paxDetail1_Form']//select[@id='pax1_stateselect']");
	public static By txtZipG1 = By.xpath("//div[@id='paxDetail1_Form']//input[@id='pax1_postalCode']");
	public static By btnSaveG1 = By.xpath("//div[@id='paxDetail1_Form']//button[@id='next-passenger-1']");
	
	public static By btntitleG2 = By.xpath("//div[@id='paxDetail2_Form']//select[@id='pax2_title']");
	public static By txtfirstnameG2 = By.xpath("//div[@id='paxDetail2_Form']//input[@id='pax2_firstName']");
	public static By txtmiddlenameG2 = By.xpath("//div[@id='paxDetail2_Form']//input[@id='pax2_middleName']");
	public static By txtlastnameG2 = By.xpath("//div[@id='paxDetail2_Form']//input[@id='pax2_lastName']");
	public static By txtmonthG2 = By.xpath("//div[@id='paxDetail2_Form']//input[@id='pax2_birthMonth']");
	public static By txtdateG2 = By.xpath("//div[@id='paxDetail2_Form']//input[@id='pax2_birthDate']");
	public static By txtyearG2 = By.xpath("//div[@id='paxDetail2_Form']//input[@id='pax2_birthYear']");
	public static By btnaddressG2 = By.xpath("//div[@id='paxDetail2_Form']//select[@id='pax2-address']");
	public static By btnUpdateG2 = By.xpath("//div[@id='paxDetail2_Form']//button[@id='next-passenger-2']");
	
	
	public WebDriver driver;
	public ActionsLibrary actionLib;
	public ExtentLogs extentLogs=new ExtentLogs();
	Optional<Long> timeoutInSecond = Optional.of(Long.parseLong("100000"));
	public GuestPage(WebDriver driver)
	{
		if(CommonVariables.getDriver()==null){
			CommonVariables.setDriver(driver);
		}
		actionLib = CommonVariables.getActionLib();
		try {
			if(!ConfigManager.ArePropertiesSet.get()){
				ConfigManager.setProperties();
				ConfigManager.UpdateProperties();
			}
		} 
		catch (Exception e) {
			System.out.println("Failed to load Properties file");
		}
	}
	
   public void clickOn(By by) throws Throwable{
		
		try
		{
			actionLib.Click(CommonVariables.CommonDriver.get().findElement(by));
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
		
	}

	public void selectTitle(String value) throws Throwable{
		try
		{
			actionLib.FindElement(GuestPage.btntitleG1, timeoutInSecond).click();
			actionLib.selectBySendkeys(GuestPage.btntitleG1, value,"Title DropDown");	
			extentLogs.pass("Title", "Title Value selected successfully.");
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("Title", "Selecting Title is Unsuccessful");
			
		}
		
	}
	public void selectType(String value) throws Throwable{
		try
		{
			actionLib.selectByVisibleText(GuestPage.btnselecttypeG1, value, "Type DropDown");
		    extentLogs.pass("Type", "Type Value selected successfully.");
			
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("Type", "Selecting Type is Unsuccessful");
			
		}
		
	}
	
	public void Fillfield(By by, String value) throws Throwable{
		try
		{			
			actionLib.FindElement(by, timeoutInSecond).sendKeys(value);
			extentLogs.pass("Filling text Field", "Successfully filled the value" + value + " in the field");
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.pass("Filling text Field", "Failed to fil the value" + value + " in the field");
		}
		
	}

	public void selectAddressGuest2(String value) throws Throwable{
		try
		{
			actionLib.selectByVisibleText(GuestPage.btnaddressG2, value, "Address DropDown");
		    extentLogs.pass("Address Guest 2", "Address for guest 2 is successfully selected as Guest 1");
			
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("Address Guest 2", "Selecting address for guest 2 is Unsuccessful");
			
		}
		
	}
	
	public void selectAddressLookUp(By by,String value) throws Throwable{
		try
		{
			actionLib.FindElement(by, timeoutInSecond).click();
			actionLib.selectBySendkeys(by, value,"Address Look up");	
			extentLogs.pass("Address ", "Address Look up is selected successfully.");
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
			extentLogs.fail("Address", "Selecting Address is Unsuccessful");
			
		}
		
	}
	
	

}
