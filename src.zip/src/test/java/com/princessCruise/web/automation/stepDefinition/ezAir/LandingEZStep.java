package com.princessCruise.web.automation.stepDefinition.ezAir;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.princessCruise.web.automation.accelerators.ActionsLibrary;
import com.princessCruise.web.automation.accelerators.TestEngineWeb;
import com.princessCruise.web.automation.fileutils.ExcelReader;
import com.princessCruise.web.automation.logs.ExtentLogs;
import com.princessCruise.web.automation.pages.ezAir.LandingEZ;
import com.princessCruise.web.automation.pages.myPrincess.OverrideLocationPage;
import com.princessCruise.web.automation.utilities.CommonVariables;

import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.testng.TestNGCucumberRunner;
@CucumberOptions(features="C:\\PrincessCruises_31_08_2017\\princessCruise\\src\\test\\resources\\testFeature\\ezAir\\LandingEZ.feature",plugin = "json:C:\\PrincessCruises_31_08_2017\\princessCruise\\target\\cucumber-report-composite.json")

public class LandingEZStep extends TestEngineWeb {
	private LandingEZ landingEZ;	
	private OverrideLocationPage orLocationPg;
	public ActionsLibrary actionLib;
	private String testCaseFailureReason = "";
	private boolean testCaseStatus = true;
	private String locationURL,direction,classValue,maxStops,airline,sortBy,header;
	protected String sheetPath = System.getProperty("user.dir").replace("\\", "/") + "/testdata/ezAir/TestData.xlsx";
	protected String sheetName = "LandingEZ";
	Map<String, List<String>> testdata = null;
	private ExtentLogs extentLogs = new ExtentLogs();

	public void TestCaseStatus(Boolean status, String reason) {
		if (status == false) {
			Assert.fail("Test Case Failed because - " + reason);
		}
	}

	@Test(groups = "smoke", description = "Landing EZ Air")
	public void landingEZAir() {
		new TestNGCucumberRunner(getClass()).runCukes();
	}

	@After
	public void after(Scenario scenario){
		System.out.println("This is after scenario: "+ scenario.getName().toString());
		extentLogs.info(scenario.getName().toString()+" Scenario", "Ends");
	}
	@Before()
	public void beforeMethod(Scenario scenario) throws IOException {
		scenario.getId();
		System.out.println("This is before scenario: "+ scenario.getName().toString());
		extentLogs.info(scenario.getName().toString()+" Scenario", "Starts");		
		this.locationURL = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Url");
		this.direction = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Direction");
		this.classValue = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Class");
		this.maxStops = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Stops");
		this.airline = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Airline");
		this.sortBy = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Sort");
		this.header = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "LandingPageHeader");
		landingEZ = new LandingEZ(CommonVariables.CommonDriver.get());
		orLocationPg = new OverrideLocationPage(CommonVariables.CommonDriver.get());
		actionLib = CommonVariables.getActionLib();
	}
	@Given("^Launch EZ Air Application$")
	public void launch_EZ_Air_Application() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		actionLib.OpenUrl(locationURL);
	}
	@Then("^Enter Polar booking at end of link	Landing page should display$")
	public void enter_Polar_booking_at_end_of_link_Landing_page_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		landingEZ.verifyLandingPageIsDisplayed(header);
	}

	@Then("^Tell us who yare are booking for Should list all guests from Polar booking$")
	public void tell_us_who_yare_are_booking_for_Should_list_all_guests_from_Polar_booking() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyAllGuests(LandingEZ.chkGuest1);
		landingEZ.verifyAllGuests(LandingEZ.chkGuest2);
	}

	@Then("^Direction dropdown Should default to Departure and Return$")
	public void direction_dropdown_Should_default_to_Departure_and_Return() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyFlightOptionDropDowns(LandingEZ.ddnDirection, direction);
	}

	@Then("^Class	Should default to Economy$")
	public void class_Should_default_to_Economy() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyFlightOptionDropDowns(LandingEZ.ddnClass, classValue);
	}
	@Then("^Maximum Stops	Should defaults to Any$")
	public void maximum_Stops_Should_defaults_to_Any() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyDropDownDefaultValue(maxStops,LandingEZ.ddnMaxStops);
	}
	@Then("^Airline	Should default to All$")
	public void airline_Should_default_to_All() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyFlightOptionDropDowns(LandingEZ.ddnAirline, airline);
	}
	@Then("^Departure To dropdown and Return From dropdown$")
	public void departure_To_dropdown_and_Return_From_dropdown() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyDepartureToAndReturnFromDropDown();
	}
	@Then("^Add another flight link Should drop down more boxes in order to add a stopover$")
	public void add_another_flight_link_Should_drop_down_more_boxes_in_order_to_add_a_stopover() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyRetAndDepAddFlight(LandingEZ.departureFormFields, LandingEZ.btnDepAddFlight);
		Thread.sleep(5000);
		landingEZ.verifyRetAndDepAddFlight(LandingEZ.returnFormFields, LandingEZ.btnRetAddFlight);
	}
	@Then("^Select Your Depart Flight	Should display home airport to port city and date$")
	public void select_Your_Depart_Flight_Should_display_home_airport_to_port_city_and_date() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyFromPortAndToPortAndDate("Departure",LandingEZ.lblFromAndToCity);
	}
	@Then("^Select Your Return Flight	Should display port city to home city and date$")
	public void select_Your_Return_Flight_Should_display_port_city_to_home_city_and_date() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyFromPortAndToPortAndDate("Return",LandingEZ.lblRetFromAndToCity);
	}
	@Then("^Currency- Fares in XXX Should be correct currency displaying$")
	public void currency_Fares_in_XXX_Should_be_correct_currency_displaying() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyCurrencyFares();
	}
	@Then("^Departure  From box is not null$")
	public void departure_From_box_is_not_null() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		landingEZ.getToCity(LandingEZ.ddnDepFrom);	
	}

	@Then("^Departure To dropdown is not null$")
	public void departure_To_dropdown_is_not_null() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		landingEZ.getFromCity(LandingEZ.ddnDepTo);
	}

	@Then("^Return From dropdown is not null$")
	public void return_From_dropdown_is_not_null() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		landingEZ.getFromCity(LandingEZ.ddnReturnFrom);
	}

	@Then("^Return To dropdown is not null$")
	public void return_To_dropdown_is_not_null() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		landingEZ.getToCity(LandingEZ.txtBoxReturnTo);	
	}
	@Then("^Cruise Deprature and Arrive On Box is not null$")
	public void cruise_Deprature_and_Arrive_On_Box_is_not_null() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		landingEZ.verifyFieldValue(LandingEZ.txtBoxArriveOn);
		landingEZ.verifyFieldValue(LandingEZ.lblCruiseDeparture);
	}

	@Then("^Cruise Return	and Leave On Box is not null$")
	public void cruise_Return_and_Leave_On_Box_is_not_null() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		landingEZ.verifyFieldValue(LandingEZ.txtBoxLeaveOn);
		landingEZ.verifyFieldValue(LandingEZ.lblCruiseReturn);
	}
	@Then("^Departure Arrive by dropdown is not null$")
	public void departure_Arrive_by_dropdown_is_not_null() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		landingEZ.verifyFieldValue(LandingEZ.ddnArriveBy);
	}

	@Then("^Return Leave at dropdown is not null$")
	public void return_Leave_at_dropdown_is_not_null() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		landingEZ.verifyFieldValue(LandingEZ.ddnLeaveAt);
	}
	@Then("^Get Default Return From and To City Value$")
	public void get_Default_Return_From_and_To_City_Value() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.getFromCity(LandingEZ.ddnReturnFrom);
		landingEZ.getToCity(LandingEZ.txtBoxReturnTo);	
	
	}
	
	@Then("^Click On Search Button$")
	public void click_On_Search_Button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.clickOnSearchButton();
		landingEZ.verifyEZAirLogo();
	}
	@Then("^Steps Bar	Should display One to five$")
	public void steps_Bar_Should_display_One_to_five() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		landingEZ.verifyStepBar();
	}
	@Then("^Get Default Departure From and To City Value$")
	public void get_Default_Departure_From_and_To_City_Value() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.getFromCity(LandingEZ.ddnDepTo);
		landingEZ.getToCity(LandingEZ.ddnDepFrom);	
	}
	@Then("^flights found Should display correct number of flight options listed on page$")
	public void flights_found_Should_display_correct_number_of_flight_options_listed_on_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyNoOfFlightsFound();
	}
	@Then("^Sort by dropdown Should default to Fare low to high$")
	public void sort_by_dropdown_Should_default_to_Fare_low_to_high() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyDropDownDefaultValue(sortBy,LandingEZ.ddnSortBy);
	}
	@Then("^What are Flexible and Restricted Fares Link Should be able to click and have a lightbox display$")
	public void what_are_Flexible_and_Restricted_Fares_Link_Should_be_able_to_click_and_have_a_lightbox_display() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.clickOnWhatAreFlexAndRestFares();
	}

	@Then("^Filters	Should be sectioned with Fare Type, Stops, Departure Time, and Airlines$")
	public void filters_Should_be_sectioned_with_Fare_Type_Stops_Departure_Time_and_Airlines() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyFilters();
	}

	@Then("^Flight options Should display Airline name, flight schedule and duration$")
	public void flight_options_Should_display_Airline_name_flight_schedule_and_duration() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyFlightOptions();
	}

	@Then("^Click show details Light box should display with a breakdown of flight schedule$")
	public void click_show_details_Light_box_should_display_with_a_breakdown_of_flight_schedule() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.clickOnShowDetails();
	}

	@Then("^Click fare restrictions	Light box should display the descriptions of flexible and restricted fare types$")
	public void click_fare_restrictions_Light_box_should_display_the_descriptions_of_flexible_and_restricted_fare_types() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.clickOnFareRestrictions();
	}
	@Then("^Fare Card	Should Diplay round trip for Flexible type$")
	public void fare_Card_Should_Diplay_round_trip_for_Flexible_type() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifyDataIsDisplayed(LandingEZ.lblFlexibleFareCard);
	}
	@Then("^Fare Card	Should Diplay non refundable for restricted type$")
	public void fare_Card_Should_Diplay_non_refundable_for_restricted_type() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		landingEZ.verifyDataIsDisplayed(LandingEZ.lblRestrictedFareCard);
	}

	@Then("^Click Select on flexible fare card Should be taken to Return Flight options$")
	public void click_Select_on_flexible_fare_card_Should_be_taken_to_Return_Flight_options() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.vereifyReturnFlightPage(LandingEZ.btnDepFlexibleSelect);
	}
	@Then("^Click Select on restricted fare card Should be taken to Return Flight options$")
	public void click_Select_on_restricted_fare_card_Should_be_taken_to_Return_Flight_options() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.vereifyReturnFlightPage(LandingEZ.btnDepRestrictedSelect);
	}
	@Then("^Click Select on fare card Should be taken to Summary page$")
	public void click_Select_on_fare_card_Should_be_taken_to_Summary_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifySummaryPage(LandingEZ.btnRetFlexibleSelect);
	}
	@Then("^Click Select on restricted fare card Should be taken to Summary page$")
	public void click_Select_on_restricted_fare_card_Should_be_taken_to_Summary_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		landingEZ.verifySummaryPage(LandingEZ.btnRetRestrictedSelect);
	}

}
