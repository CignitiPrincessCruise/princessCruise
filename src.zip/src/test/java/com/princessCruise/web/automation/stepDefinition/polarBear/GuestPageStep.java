package com.princessCruise.web.automation.stepDefinition.polarBear;

import com.princessCruise.web.automation.accelerators.TestEngineWeb;
import com.princessCruise.web.automation.fileutils.ExcelReader;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import org.testng.annotations.Test;
import com.princessCruise.web.automation.accelerators.ActionsLibrary;
import com.princessCruise.web.automation.logs.ExtentLogs;
import com.princessCruise.web.automation.pages.polarBear.GuestPage;
import com.princessCruise.web.automation.utilities.CommonVariables;
import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.testng.TestNGCucumberRunner;

@CucumberOptions(features="C:\\Users\\E003919\\Desktop\\Pavan\\Pavan\\21082017\\princessCruise\\src\\test\\resources\\testFeature\\polarBear\\GuestPage.feature",plugin = "json:C:\\Users\\E003919\\Desktop\\Pavan\\Pavan\\21082017\\princessCruise\\target\\cucumber-report-composite.json")
public class GuestPageStep extends TestEngineWeb{
	
	private GuestPage GuestPageobj;
	public ActionsLibrary actionLib;
	private String title, type, EmailAddress, FirstName, MiddleName, LastName, FirstName1, MiddleName1, LastName1, Month, Day, Year, Address, City, State, PrimaryPhNo, Address2;
	protected String sheetPath = System.getProperty("user.dir").replace("\\", "/") + "/testdata/polarBear/TestData.xlsx";
	protected String sheetName = "GuestPage";
	Map<String, List<String>> testdata = null;
	private ExtentLogs extentLogs = new ExtentLogs();

	@Test(groups = "smoke", description = "Guest Page")
	public void StateRoom() {
		new TestNGCucumberRunner(getClass()).runCukes();
	}

	@After
	public void after(Scenario scenario){
		System.out.println("This is after scenario: "+ scenario.getName().toString());
		extentLogs.info(scenario.getName().toString()+" Scenario", "Ends");
	}

	@Before()
	public void beforeMethod(Scenario scenario) throws IOException {
		scenario.getId();
		System.out.println("This is before scenario: "+ scenario.getName().toString());
		extentLogs.info(scenario.getName().toString()+" Scenario", "Starts");				
		this.title = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "MaleTitle");
		this.type = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Type");
		this.EmailAddress = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "EmailAddress");
		this.FirstName = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "FirstName");
		this.MiddleName = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "MiddleName");
		this.LastName = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "LastName");
		this.FirstName1 = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "FirstName1");
		this.MiddleName1 = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "MiddleName1");
		this.LastName1 = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "LastName1");
		this.Month = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Month");
		this.Day = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Day");
		this.Year = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Year");
		this.Address = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Address");		
		this.City  = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "City");
		this.State = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "State");
		this.PrimaryPhNo = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "PrimaryPhNo");
		this.Address2 = ExcelReader.fn_GetCellData(this.sheetPath, this.sheetName, 1, "Address2");
		GuestPageobj  = new GuestPage(CommonVariables.CommonDriver.get());
		actionLib = CommonVariables.getActionLib();
	}
	
	@Then("^Select Title$")
	public void select_Title() throws Throwable {
		GuestPageobj.selectTitle(title);
	}

	@Then("^Enter First Name$")
	public void enter_First_Name() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtfirstnameG1, FirstName);
	}

	@Then("^Enter Middle Name$")
	public void enter_Middle_Name() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtmiddlenameG1, MiddleName);	    
	}

	@Then("^Enter Last Name$")
	public void enter_Last_Name() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtlastnameG1, LastName);	    
	}

	@Then("^Enter Month$")
	public void enter_Month() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtmonthG1, Month);
	
	}

	@Then("^Enter Day$")
	public void enter_Day() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtdateG1, Day);
	}

	@Then("^Enter year$")
	public void enter_year() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtyearG1, Year);	    
	}

	@Then("^Enter Address Look Up$")
	public void enter_Address_Look_Up() throws Throwable {
		GuestPageobj.selectAddressLookUp(GuestPage.txtaddressG1, Address);	
	}

	@Then("^Enter Primary Phone Number$")
	public void enter_Primary_Phone_Number() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtPrimaryphnoG1, PrimaryPhNo);	  
	}

	@Then("^Select Type$")
	public void select_Type() throws Throwable {
		GuestPageobj.selectType(type);
	    
	}

	@Then("^Enter email Address$")
	public void enter_email_Address() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtmailG1, EmailAddress);
	  
	}

	@Then("^Confirm Email Address$")
	public void confirm_Email_Address() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtconfrmmailG1, EmailAddress);
	}

	@Then("^Click 'Save' button$")
	public void click_Save_button() throws Throwable {
		GuestPageobj.clickOn(GuestPage.btnSaveG1);
	}

	@When("^Click on continue Button$")
	public void click_on_continue_Button() throws Throwable {
		GuestPageobj.clickOn(GuestPage.btncontinue);
	}

	@Then("^Click 'Sign In' on page next to Already Registered\\.$")
	public void click_Sign_In_on_page_next_to_Already_Registered() throws Throwable {

	}

	@Then("^Input Email Address$")
	public void input_Email_Address() throws Throwable {
	 }

	@Then("^Input Password$")
	public void input_Password() throws Throwable {
	    
	}

	@Then("^Click 'Sign In' button$")
	public void click_Sign_In_button() throws Throwable {
	    
	}

	@Then("^'Save' button to save guest (\\d+) details$")
	public void save_button_to_save_guest_details(int arg1) throws Throwable {
	    
	}
	
	@Then("^Select Title of second guest$")
	public void select_Title_of_second_guest() throws Throwable {
		GuestPageobj.selectTitle(title);
	}

	@Then("^Enter First Name of second guest$")
	public void enter_First_Name_of_second_guest() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtfirstnameG2, FirstName1);
	}

	@Then("^Enter Middle Name of second guest$")
	public void enter_Middle_Name_of_second_guest() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtmiddlenameG2, MiddleName1);
	}

	@Then("^Enter Last Name of second guest$")
	public void enter_Last_Name_of_second_guest() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtlastnameG2, LastName1);	
	}

	@Then("^Enter Month of second guest$")
	public void enter_Month_of_second_guest() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtmonthG2, Month);
	}

	@Then("^Enter Day of second guest$")
	public void enter_Day_of_second_guest() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtdateG2, Day);
	}

	@Then("^Enter year	of second guest$")
	public void enter_year_of_second_guest() throws Throwable {
		GuestPageobj.Fillfield(GuestPage.txtyearG2, Year);

	}

	@Then("^Select Address of second guest$")
	public void select_Address_of_second_guest() throws Throwable {
		GuestPageobj.selectAddressGuest2(Address2);
	}

	@Then("^Click on update button$")
	public void click_on_update_button() throws Throwable {
		GuestPageobj.clickOn(GuestPage.btnUpdateG2);		
	}
	
	
	
	

}
