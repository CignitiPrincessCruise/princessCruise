package com.princessCruise.web.automation.stepDefinition.polarBear;

import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.princessCruise.web.automation.accelerators.ActionsLibrary;
import com.princessCruise.web.automation.accelerators.TestEngineWeb;
import com.princessCruise.web.automation.logs.ExtentLogs;
import com.princessCruise.web.automation.pages.polarBear.*;
import com.princessCruise.web.automation.utilities.CommonVariables;
import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.testng.TestNGCucumberRunner;
// TODO: Auto-generated Javadoc

/**
 * The Class PlanAcruiseStep.
 */
@CucumberOptions(features="C:\\Users\\E003919\\Desktop\\Pavan\\Pavan\\21082017\\princessCruise\\src\\test\\resources\\testFeature\\polarBear\\SearchResults.feature",plugin = "json:C:\\Users\\E003919\\Desktop\\Pavan\\Pavan\\21082017\\princessCruise\\target\\cucumber-report-composite.json")

public class SearchResultsStep extends TestEngineWeb{
	
	private SearchResultsPage SearchResultsPageObj;
	public ActionsLibrary actionLib;	
	private ExtentLogs extentLogs = new ExtentLogs();
	protected String sheetPath = System.getProperty("user.dir").replace("\\", "/") + "/testdata/polarBear/TestData.xlsx";
	protected String sheetName = "HomePage";
	
	public void TestCaseStatus(Boolean status, String reason) {
		if (status == false) {
			Assert.fail("Test Case Failed because - " + reason);
		}
	}
	
	@Test(groups = "smoke", description = "Search Results Page")
    public void SearchResults() {
        new TestNGCucumberRunner(getClass()).runCukes();
    }


	/**
	 * After.
	 *
	 * @param scenario the scenario
	 */
	@After
	public void after(Scenario scenario){
		System.out.println("This is after scenario: "+ scenario.getName().toString());
		extentLogs.info(scenario.getName().toString()+" Scenario", "Ends");
	}

	/**
	 * Before method.
	 *
	 * @param scenario the scenario
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	@Before()
	public void beforeMethod(Scenario scenario) throws IOException {
		scenario.getId();
		extentLogs.info(scenario.getName().toString()+" Scenario", "Starts");
		System.out.println("This is before scenario: "+ scenario.getName().toString());
		extentLogs.info(scenario.getName().toString()+" Scenario", "Starts");
		SearchResultsPageObj = new SearchResultsPage(CommonVariables.CommonDriver.get());
		actionLib = CommonVariables.getActionLib();
	}
	
	@Then("^Itineraries text should appear as a result$")
	public void itineraries_text_should_appear_as_a_result() throws Throwable {
		SearchResultsPageObj.verifyItineraries();
	}

	@When("^Click on the View results button$")
	public void click_on_the_View_results_button() throws Throwable {
		SearchResultsPageObj.clickOnViewResultButon();
	}

	@When("^Click on the Cruise Deatils button$")
	public void click_on_the_Cruise_Deatils_button() throws Throwable {
		SearchResultsPageObj.clickOnCruiseDetailsButon();
	}

	@Then("^Pricing is per person, double occupancy… text should appear as result$")
	public void pricing_is_per_person_double_occupancy_text_should_appear_as_result() throws Throwable {
		SearchResultsPageObj.verifyPricingText();
	}
	
	@Then("^Click on 'Refine Search' Button$")
	public void click_on_Refine_Search_Button() throws Throwable {
		SearchResultsPageObj.clickOnRefineSearchButon();		
	   
	}


	

}